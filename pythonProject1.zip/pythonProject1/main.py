import requests
import telebot

# Устанавливаем токен для бота
bot_token = '5995193636:AAEt8kfLmx_pctVgJMS6oZ6Du0EzR46y8MI'

# Инициализируем бота
bot = telebot.TeleBot(bot_token)

# Функция обработки команды /start
@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Привет, я бот viki, предназначенный для поиска статей на Википедии. Просто отправь мне запрос и я найду для тебя статью.")

# Функция обработки запроса пользователя
@bot.message_handler(func=lambda message: True)
def search_wikipedia(message):
    # Получаем запрос пользователя
    query = message.text

    # Отправляем запрос к MediaWiki API
    url = f"https://ru.wikipedia.org/w/api.php?action=query&format=json&prop=extracts&titles={query}&redirects=1&exintro=1&explaintext=1"
    response = requests.get(url)

    # Получаем результаты и форматируем их в сообщение для отправки
    pages = response.json()['query']['pages']
    if "-1" in pages:
        message_text = f"К сожалению страница '{query}' не найдена. Попробуй изменить запрос."

    else:
        page_id = list(pages.keys())[0]
        page_title = pages[page_id]['title']
        page_summary = pages[page_id]['extract']
        message_text = f"<b>{page_title}</b>\n\n{page_summary}"

    bot.send_message(chat_id=message.chat.id, text=message_text, parse_mode='HTML')


# Запускаем бота
bot.polling()